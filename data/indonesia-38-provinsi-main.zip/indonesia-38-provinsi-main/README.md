# Data Wilayah 38 Provinsi Indonesia
Data meliputi Provinsi, Kabupaten/Kota, Kecamatan, dan Kelurahan. Kode Penomoran wilayah berdasarkan format yang berlaku di Kementerian Dalam Negeri sebagai contoh berikut ini:

> - **31.74.06.1003** merupakan kode Wilayah Kelurahan Pondok Labu dengan format pemisahan dengan . (titik)
> - **31** merupakan Kode Provinsi DKI Jakarta
> - **31.74** merupakan Kode Kota Jakarta Selatan
> - **31.74.06** merupakan Kode Kecamatan Cilandak
> - **31.74.06.1003** merupakan Kode Kelurahan Pondok Labu
